public class Round {
	private int sittingPlayers;
	private boolean roundContinue = true;
	private int roundTotal;
	private int roundInProgress;

	public Round(int roundInProgress) {
		this.roundInProgress = roundInProgress;
	}

	public final int getSittingPlayers() {
		return sittingPlayers;
	}

	public final void setSittingPlayers(int sittingPlayers) {
		this.sittingPlayers = sittingPlayers;
	}

	public final void incrementSittingPlayers() {
		this.sittingPlayers++;
	}

	public final boolean isRoundContinue() {
		return roundContinue;
	}

	public final void setRoundContinue(boolean roundContinue) {
		this.roundContinue = roundContinue;
	}

	public final int getRoundTotal() {
		return roundTotal;
	}

	public final void setRoundTotal(int roundTotal) {
		this.roundTotal = roundTotal;
	}

	public final void updateRoundTotal(int totalDiceValue) {
		this.roundTotal += totalDiceValue;
	}

	public final int getRoundInProgress() {
		return roundInProgress;
	}

	public final void setRoundInProgress(int roundInProgress) {
		this.roundInProgress = roundInProgress;
	}

	public boolean checkRoundStatus() {
		if (sittingPlayers > 0) {
			roundContinue = false;
			return true;
		}
		return false;
	}

	public void checkRoundStatus(int numberOfPlayers) {
		if (sittingPlayers == numberOfPlayers) {
			roundContinue = false;
		}
	}

}
