public class OutputWriter {
	public static void printText(String text) {
		System.out.println(text);
	}

	public static void printScoreHeader() {
		System.out.printf("%-10s%12s%12s%12s%12s%12s%12s%n", "Player", "Round_1", "Round_2", "Round_3", "Round_4",
				"Round_5", "Total");
	}

	public static void pringGameScore(Player player) {
		System.out.printf("%-10s%12d%12d%12d%12d%12d%12d%n", player.getName(), player.getRoundScores()[0],
				player.getRoundScores()[1], player.getRoundScores()[2], player.getRoundScores()[3],
				player.getRoundScores()[4], player.getTotalScore());
	}
}
