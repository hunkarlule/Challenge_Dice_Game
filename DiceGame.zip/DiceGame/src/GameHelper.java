public class GameHelper {
	private Dice firstDice;
	private Dice secondDice;
	private Player[] players;
	private InputReader inputReader;
	private String formatted;

	public GameHelper() {
		firstDice = new Dice();
		secondDice = new Dice();
		inputReader = new InputReader();
	}

	public final Dice getFirstDice() {
		return firstDice;
	}

	public final void setFirstDice(Dice firstDice) {
		this.firstDice = firstDice;
	}

	public final Dice getSecondDice() {
		return secondDice;
	}

	public final void setSecondDice(Dice secondDice) {
		this.secondDice = secondDice;
	}

	public final Player[] getPlayers() {
		return players;
	}

	public final void setPlayers(Player[] players) {
		this.players = players;
	}

	public final InputReader getInputReader() {
		return inputReader;
	}

	public final void setInputReader(InputReader inputReader) {
		this.inputReader = inputReader;
	}

	public final String getFormatted() {
		return formatted;
	}

	public final void setFormatted(String formatted) {
		this.formatted = formatted;
	}

	public void setGame() {
		createPlayers();
	}

	public void runGame(Round newRound) {
		for (Player player : players) {
			player.setPlayerSitting(false);
		}

		formatted = String.format("Round %d is starting:%n", newRound.getRoundInProgress());
		OutputWriter.printText(formatted);

		while (newRound.isRoundContinue()) {
			int valueOfFirstDice = firstDice.rollDice();
			int valueOfSecondDice = secondDice.rollDice();

			formatted = String.format("Dice values: %d | %d%n", valueOfFirstDice, valueOfSecondDice);
			OutputWriter.printText(formatted);

			if (valueOfFirstDice != 1 && valueOfSecondDice != 1) {
				newRound.updateRoundTotal(valueOfFirstDice + valueOfSecondDice);
				formatted = String.format("Point to gain if player choose to sit: %d%n", newRound.getRoundTotal());
				OutputWriter.printText(formatted);
			}

			diceEvaluation(valueOfFirstDice, valueOfSecondDice, newRound);
		}
	}

	private void diceEvaluation(int firstDice, int secondDice, Round round) {
		if (firstDice == 1 && secondDice == 1) {
			if (round.checkRoundStatus())
				for (Player p : players) {
					p.resetPlayerScores();
				}
		} else if (firstDice == 1 || secondDice == 1) {
			round.checkRoundStatus();
		} else {
			for (Player player : players) {
				addScores(player, round);
			}
			round.checkRoundStatus(players.length);
		}
	}

	private void addScores(Player player, Round newRound) {
		String answer = "N";
		if (!player.isPlayerSitting()) {
			if (player instanceof ComputerPlayer) {
				if (((ComputerPlayer) player).decideSitting(newRound)) {
					answer = "Y";
				}
				OutputWriter.printText(player.getName() + " choice is : " + answer);

			} else {
				InputReader inputReader = new InputReader();
				OutputWriter.printText(player.getName() + " do you want to sit ?: Y /N :");
				answer = inputReader.getStringInput();
			}

			if (answer.equalsIgnoreCase("Y")) {
				player.addRoundScore(newRound.getRoundInProgress() - 1, newRound.getRoundTotal());
				newRound.incrementSittingPlayers();
			}
		}
	}

	// to create players
	private void createPlayers() {
		int numberOfPlayers = 0;
		do {
			OutputWriter.printText("Enter the number of human players: ");
			numberOfPlayers = inputReader.getIntInput();
		} while (numberOfPlayers <= 0);

		players = new Player[numberOfPlayers + 1];

		for (int i = 1; i <= numberOfPlayers; i++) {
			OutputWriter.printText("Enter name of " + i + "." + "player: ");
			String name = inputReader.getStringInput();
			players[i - 1] = new Player(name);
		}

		players[players.length - 1] = new ComputerPlayer();
		OutputWriter.printText("Computer was added as last player!!");
	}

	// to display scores
	public static void displayScores(Player[] players) {
		OutputWriter.printScoreHeader();
		for (int i = 0; i < players.length; i++) {
			OutputWriter.pringGameScore(players[i]);
		}

	}
}
