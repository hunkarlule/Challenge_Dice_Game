import java.util.Random;

public class Dice {
	public int diceValue;
	// public int die2;

	public int rollDice() {
		Random randomNumber = new Random();
		diceValue = randomNumber.nextInt(6) + 1;
		return diceValue;
		// die2 = randomNumber.nextInt(6) +1;
	}

}
