public class ComputerPlayer extends Player {

	private final static int MIN_ROUND_SCORE = 15;
	private final static int AVG_ROUND_SCORE = 22;

	public ComputerPlayer() {
		super("Computer");
	}

	public boolean decideSitting(Round round) {
		int averageScore = (getTotalScore() +round.getRoundTotal()) / round.getRoundInProgress() ;
		if(averageScore >= AVG_ROUND_SCORE) {
			return true;
		}
		
		if (round.getSittingPlayers() > 0) {
			if (round.getRoundTotal() >= MIN_ROUND_SCORE) {
				return true;
			}
		}
		else {
			if (round.getRoundTotal() >= AVG_ROUND_SCORE) {
				return true;
			}
		}
		
		return false;
	}

}
