import java.util.Arrays;

public class Player {
	 private String name;
	 private int[] roundScores;
	 private int totalScore;
	 private boolean playerSitting;
	 

	Player(String name) {
		setName(name);
		roundScores = new int[5];
	}

	public void addRoundScore(int round, int roundScore) {
		roundScores[round] = roundScore;
		playerSitting = true;
		totalScore = totalScore + roundScore;
	}

	public void resetPlayerScores() {
		if (!playerSitting) {
			Arrays.fill(roundScores, 0);
			totalScore = 0;
		}
	}
	
//	public String decideSitting() {
//		InputReader inputReader = new InputReader();
//		OutputWriter.printText(this.getName() + " do you want to sit ?: Y /N :");
//		String answer = inputReader.getStringInput();
//		return answer;
//	}

	public final String getName() {
		return name;
	}

	public final void setName(String name) {
		this.name = name;
	}

	public final int[] getRoundScores() {
		return roundScores;
	}

	public final void setRoundScores(int[] roundScores) {
		this.roundScores = roundScores;
	}

	public final int getTotalScore() {
		return totalScore;
	}

	public final void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}

	public final boolean isPlayerSitting() {
		return playerSitting;
	}

	public final void setPlayerSitting(boolean playerSitting) {
		this.playerSitting = playerSitting;
	}
	
	

}
