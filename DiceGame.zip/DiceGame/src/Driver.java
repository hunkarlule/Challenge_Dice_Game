public class Driver {
	public static void main(String[] args) {
		GameHelper newGame = new GameHelper();
		
		
		newGame.setGame();
		
		for (int i = 0; i < 5; i++) {
			Round newRound = new Round(i + 1);
			newGame.runGame(newRound);
			GameHelper.displayScores(newGame.getPlayers());
		}
	}
}
